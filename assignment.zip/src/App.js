import EmployeeDetails from "./components/EmployeeDetails";
import "./styles.css";

const employeeDetailsList = [
  {
    person: {
      name: "Prerna Jha",
      avatar: "profile.jpg"
    },
    city: "Mumbai",
    email: "prernajha@gmail.com",
    joiningDate: "12/02/2018",
    role: "UI Designer"
  },
  {
    person: {
      name: "Rukmini Pandit",
      avatar: "profile.jpg"
    },
    city: "Delhi",
    email: "rukminipandit@gmail.com",
    joiningDate: "09/02/2022",
    role: "Front-end Developer"
  },
  {
    person: {
      name: "Nandhini Lingesh",
      avatar: "profile.jpg"
    },
    city: "Delhi",
    email: "nandhinilingesh@gmail.com",
    joiningDate: "30/06/2019",
    role: "UX Designer"
  },
  {
    person: {
      name: "Ankit Singh",
      avatar: "profile.jpg"
    },
    city: "Kolkata",
    email: "ankitsingh@gmail.com",
    joiningDate: "11/11/2017",
    role: "Backend Developer"
  },
  {
    person: {
      name: "Amith Kumar",
      avatar: "profile.jpg"
    },
    city: "Mumbai",
    email: "amithkumar@gmail.com",
    joiningDate: "24/07/2020",
    role: "Front-end Developer"
  },
  {
    person: {
      name: "Shalini Singhla",
      avatar: "profile.jpg"
    },
    city: "Mumbai",
    email: "shalinisinghla@gmail.com",
    joiningDate: "17/09/2017",
    role: "UX Designer"
  },
  {
    person: {
      name: "Abhishek Singh",
      avatar: "profile.jpg"
    },
    city: "Kolkata",
    email: "abhisheksingh@gmail.com",
    joiningDate: "01/06/2017",
    role: "Front-end Developer"
  }
];

const App = () => (
  <table>
    <tr>
      <th>Name</th>
      <th>City</th>
      <th>Email Address</th>
      <th>Joining Date</th>
      <th>Role</th>
    </tr>
    {employeeDetailsList.map((eachItem) => (
      <EmployeeDetails empDetails={eachItem} />
    ))}
  </table>
);

export default App;
