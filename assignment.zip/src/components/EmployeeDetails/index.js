import "./index.css";

const EmployeeDetails = (props) => {
  const { empDetails } = props;
  const { person, city, email, joiningDate, role } = empDetails;
  const { name } = person;
  const avatar =
    "https://res.cloudinary.com/atisha/image/upload/v1669982509/unsplash_rDEOVtE7vOs_tjzvek.png";

  return (
    <tr>
      <td className="name-avatar">
        <img src={avatar} className="avatar-img" alt="avatar" />
        <p className="name">{name}</p>
      </td>
      <td>{city}</td>
      <td>{email}</td>
      <td>{joiningDate}</td>
      <td>{role}</td>
    </tr>
  );
};

export default EmployeeDetails;
